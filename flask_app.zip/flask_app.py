from flask import Flask, redirect, request, render_template

S_TP_RGB_D = []
S_TP_Fan_D = []

app = Flask(__name__, static_folder = 'assets')

@app.route("/")
def home():
    return redirect("/home")

@app.route("/home")
def home_temp():
    return render_template("home.html")

@app.route("/Student")
def Student_Login_temp():
    return render_template("S_start.html")
        
@app.route("/Teacher")
def Teacher_Login_temp():
    return render_template("T_Classes.html")

@app.route("/Student_Start")
def Student_start_temp():
    return render_template("S_start.html")

@app.route("/Student_Projects")
def Student_Projects_temp():
    return render_template("S_projects.html")

@app.route("/Student_Learn")
def Student_Learn_temp():
    return render_template("S_Learn.html")

@app.route("/Student_Track_Progress")
def Student_Track_Progress_temp():
    return render_template("S_TP.html")

@app.route("/Student_Project_Fan")
def Student_Project_Fan_temp():
    return render_template("S_projects_Fan.html")

@app.route("/Student_Project_RGB")
def Student_Project_RGB_temp():
    return render_template("S_projects_RGB.html")

@app.route("/Student_Learn_Fan")
def Student_Learn_Fan_temp():
    return render_template("S_Learn_Fan.html")

@app.route("/Student_Learn_RGB")
def Student_Learn_RGB_temp():
    return render_template("S_Learn_RGB.html")

@app.route("/Student_Track_Progress_RGB")
def Student_Track_Progress_RGB_temp():
    return render_template("S_TP_RGB.html")

@app.route("/Student_Track_Progress_Fan")
def Student_Track_Progress_Fan_temp():
    return render_template("S_TP_Fan.html")
        
@app.route("/Teacher_Track_Progress")
def Teacher_Track_Progress_temp():
    return render_template("TP_Classes.html")

#new entry for existing RGB
@app.route("/Student_Track_Progress_RGB", methods=['POST', 'GET'])
def New_Entry_TP_RGB():
    if request.method == "POST":
        ne_title = request.form["title"]
        ne_date = request.form["date"]
        ne_text = request.form["text"]
        S_TP_RGB_D.append([ne_date, ne_title, ne_text, ne_file])
    return render_template("S_TP_RGB.html", title=ne_title, date=ne_date,text=ne_text)

#new entry for existing project - Fan
@app.route("/Student_Track_Progress_Fan", methods=['POST', 'GET'])
def New_Entry_TP_Fan():
   if request.method == "POST":
        ne_title = request.form["title"]
        ne_date = request.form["date"]
        ne_text = request.form["text"]
        S_TP_Fan_D.append([ne_date, ne_title, ne_text, ne_file])
    return render_template("S_TP_Fan.html", title=ne_title, date=ne_date,text=ne_text)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=80, debug=True, threaded = True)
